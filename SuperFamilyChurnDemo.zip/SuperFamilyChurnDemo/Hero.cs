﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

public class Hero
{
    
    public String CookieID { get; set; }
    public String UserID { get; set; }
    public DateTime GameTime { get; set; }
    public String HeroCharacter { get; set; }
    public int Age { get; set; }
    public int NegativeTweetLast30Days { get; set; }
    public int PositiveTweetLast30Days { get; set; }
    public int IsMarried { get; set; }
    public int DurationMinutes { get; set; }
    public int TotalVirtualCurrency { get; set; }
    public String State { get; set; }

    public Hero()
    {
        Random r = new Random();

        // Simulating it.
        this.Age = r.Next(14, 60);
        this.NegativeTweetLast30Days = r.Next(0, 5);
        this.PositiveTweetLast30Days = r.Next(0, 5);
        this.IsMarried = r.Next(0, 1);
        this.DurationMinutes = r.Next(1, 240);
        this.TotalVirtualCurrency = r.Next(200, 5000);
        this.State = (r.Next(0, 1) == 0) ? "WA" : "CA";
    }

    override public String ToString()
    {
        return this.GameTime.ToLongDateString() + "," + this.CookieID + "," + this.UserID + "," + this.HeroCharacter;
    }
}
