﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using System.Threading.Tasks;
using System.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
//using System.IO;
//using System.Data.SqlClient;

namespace SuperFamilyChurnDemo
{
    public partial class _Default : Page
    {
        private static char[] _base62chars =
          "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghklmnopqrstuxyz"
          .ToCharArray();

        private static Random _random = new Random();
        private HttpResponseMessage response;
        private string responseString;
        private int churn;

        public static string GetBase62(int length)
        {
            var sb = new StringBuilder(length);

            for (int i = 0; i < length; i++)
                sb.Append(_base62chars[_random.Next(62)]);

            return sb.ToString();
        }

        public static string GetBase36(int length)
        {

            var sb = new StringBuilder(length);

            for (int i = 0; i < length; i++)
                sb.Append(_base62chars[_random.Next(36)]);

            return sb.ToString();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //Page loaded for the first time
                if (Session["appid"] == null)
                {
                    string appid = GetBase36(7);

                    Session.Add("appid", appid);
                    Literal2.Text = appid;
                }
                else
                {
                    Literal2.Text = Session["appid"].ToString();
                }


                // Update the textbox is nickname is defined
                if (Session["nickname"] != null)
                {
                    TextBoxName.Text = Session["nickname"].ToString();
                }
            }

            MultiView1.ActiveViewIndex = 0;
        }

        protected void ImageButtonMainPage1_Click(object sender, ImageClickEventArgs e)
        {
            // Return back to main page
            MultiView1.ActiveViewIndex = 0;
        }



        protected void ImageButtonReset_Click(object sender, ImageClickEventArgs e)
        {
            string appid = GetBase36(7);
            Session["appid"] = appid;
            Literal2.Text = appid;

            // Reset hero
            Session["hero"] = null;

        }

        protected void TimerRideInProgress_Tick(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            TimerRideInProgress.Enabled = false;

        }

        protected void ImageButtonMrStrength_Click(object sender, ImageClickEventArgs e)
        {
            GameInProgress.ImageUrl = "~/MrStrength.png";
            CreateHero("Mr Strength");
        }

        protected void ImageButtonMrEvil_Click(object sender, ImageClickEventArgs e)
        {
            GameInProgress.ImageUrl = "~/MrEvil.png";
            CreateHero("Mr Evil");
        }
        protected void ImageButtonMrOctopus_Click(object sender, ImageClickEventArgs e)
        {
            GameInProgress.ImageUrl = "~/MrOctopus.png";
            CreateHero("Mr Octopus");
        }
        protected void ImageButtonKidSwift_Click(object sender, ImageClickEventArgs e)
        {
            GameInProgress.ImageUrl = "~/KidSwift.png";
            CreateHero("Kid Swift");
        }
        protected void ImageButtonStartGame_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["nickname"] == null)
            {
                // nickname has not been defined yet
                if (TextBoxName.Text.Length > 0)
                    Session.Add("nickname", TextBoxName.Text);
            }

            MultiView1.ActiveViewIndex = 1;
        }

        protected void CreateHero(string herocharacter)
        {
            Hero item = null;

            item = new Hero();
            item.UserID = TextBoxName.Text + "(" + Literal2.Text + ")";
            item.CookieID = Literal2.Text;
            item.HeroCharacter = herocharacter;
            item.GameTime = DateTime.Now.ToUniversalTime();

            Session["hero"] = item;

            // Predict whether customer will churn
            InvokeRequestResponseService(item).Wait();


            if (this.churn == 1)
            {
                LiteralSpecial.Text = "Congratulations, you found the ultimate helmet! <BR> Using this, you won the fight!";
                ImageSpecial.Visible = true;
            }
            else
            {
                LiteralSpecial.Text = "The monster is too powerful. You lost!";
                ImageSpecial.Visible = false;

            }

            // switch view
            MultiView1.ActiveViewIndex = 2;
            TimerRideInProgress.Enabled = true;

        }

        protected async Task InvokeRequestResponseService(Hero hero)
        {

            string mlUri = ConfigurationManager.AppSettings["MLUri"]; ;

            string apiKey = ConfigurationManager.AppSettings["MLExperimentKey"];

            using (var client = new HttpClient())
            {
                var scoreRequest = new
                {

                    Inputs = new Dictionary<string, StringTable>() {
                        {
                            "input1",
                            new StringTable()
                            {
                                ColumnNames = new string[] {"Age", "NegativeTweetLast30Days", "PositiveTweetLast30Days", "IsMarried", "DurationMinutes", "TotalVirtualCurrency", "State", "Churn"},
                                Values = new string[,] {  { hero.Age.ToString(), hero.NegativeTweetLast30Days.ToString(), hero.PositiveTweetLast30Days.ToString(), "0", hero.DurationMinutes.ToString(), hero.TotalVirtualCurrency.ToString(), hero.State, "0" },  }
                            }
                        },
                                        },
                    GlobalParameters = new Dictionary<string, string>()
                    {
                    }
                };



                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
                client.BaseAddress = new Uri(mlUri);

                // WARNING: The 'await' statement below can result in a deadlock if you are calling this code from the UI thread of an ASP.Net application.
                // One way to address this would be to call ConfigureAwait(false) so that the execution does not attempt to resume on the original context.
                // For instance, replace code such as:
                //      result = await DoSomeTask()
                // with the following:
                //      result = await DoSomeTask().ConfigureAwait(false)


                response = await client.PostAsJsonAsync("", scoreRequest).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

                    dynamic jsonDe = JsonConvert.DeserializeObject(json);
                    JArray items = jsonDe.Results.output1.value.Values[0];

                    int label = Int32.Parse(items[8].ToString());
                    double scoreProb = Double.Parse(items[9].ToString());

                    //  Indicate whether the user churn
                    if (label == 1 || scoreProb > 0.1)
                        this.churn = 1;
                    else
                        this.churn = 0;

                }
                else
                {
                    //  Console.WriteLine(string.Format("The request failed with status code: {0}", response.StatusCode));

                    // Print the headers - they include the requert ID and the timestamp, which are useful for debugging the failure
                    //Console.WriteLine(response.Headers.ToString());

                    //  string responseContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false;
                    //   Console.WriteLine(responseContent);
                    //
                }

            }
        }
    }
}